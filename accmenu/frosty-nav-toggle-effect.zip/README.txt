A Pen created at CodePen.io. You can find this one at http://codepen.io/GrahamWilsdon/pen/OVoaNQ.

 Wanted to explore a nice navigation menu for mobile, pretty stoked with the results